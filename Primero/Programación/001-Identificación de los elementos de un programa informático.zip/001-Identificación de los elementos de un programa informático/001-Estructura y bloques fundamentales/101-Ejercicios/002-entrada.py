print("Ahora te voy a preguntar el nombre")
input("Introduce tu nombre: ")
print("Ahora ya sé tu nombre")
