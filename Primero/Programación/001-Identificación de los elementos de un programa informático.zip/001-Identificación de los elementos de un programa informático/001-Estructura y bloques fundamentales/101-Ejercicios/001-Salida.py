print("Hola mundo desde Python")
