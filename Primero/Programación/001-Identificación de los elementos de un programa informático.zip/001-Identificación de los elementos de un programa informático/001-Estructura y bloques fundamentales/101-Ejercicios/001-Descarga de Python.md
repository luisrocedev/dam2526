La web de descarga es
https://python.org

- Downloads

Descargáis la última versión que haya en ese momento
Para vuestro sistema operativo

Cuando iniciéis la instalación en Windows:
- Marcad la casilla de "agregar al PATH de Windows"
- Marcad "instalar para todos los usuarios"


