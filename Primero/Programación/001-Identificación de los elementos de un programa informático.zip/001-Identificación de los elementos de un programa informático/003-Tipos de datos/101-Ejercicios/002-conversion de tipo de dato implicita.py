edad = "47"
print(type(edad))

print(edad*2) # encadena

edad*1 # Conversión implícita de los datos

print(edad*2)
