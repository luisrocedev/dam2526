edad = "47"
print(type(edad))

print(edad*2) # encadena

edad = int(edad)

print(edad*2) # se trata como multiplicación
