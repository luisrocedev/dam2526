nombre = "Jose Vicente" # cadena
edad = 47 # entero
altura = 1.78 # decimal
guapo = True # booleana


