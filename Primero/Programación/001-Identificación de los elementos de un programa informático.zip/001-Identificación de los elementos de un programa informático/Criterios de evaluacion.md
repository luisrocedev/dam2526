1. Reconoce la estructura de un programa informático, identificando y relacionando los elementos propios del lenguaje de programación utilizado.

Criterios de evaluación:

a) Se han identificado los bloques que componen la estructura de un programa informático.

b) Se han creado proyectos de desarrollo de aplicaciones.

c) Se han utilizado entornos integrados de desarrollo.

d) Se han identificado los distintos tipos de variables y la utilidad específica de cada uno.

e) Se ha modificado el código de un programa para crear y utilizar variables.

f) Se han creado y utilizado constantes y literales.

g) Se han clasificado, reconocido y utilizado en expresiones los operadores del lenguaje.

h) Se ha comprobado el funcionamiento de las conversiones de tipo explícitas e implícitas.

i) Se han introducido comentarios en el código.
