edad = 47
print(edad)

# edad = edad + 5
edad += 5
print(edad)

# edad = edad - 5
edad -= 5
print(edad)

# edad = edad * 5
edad *= 5
print(edad)

# edad = edad / 5
edad /= 5
print(edad)
