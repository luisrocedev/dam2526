edad = 47

print(edad)
