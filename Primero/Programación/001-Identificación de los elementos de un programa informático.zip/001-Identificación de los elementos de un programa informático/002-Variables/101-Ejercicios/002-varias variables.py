edad = 47
nombre = "Jose Vicente"

print("Mi edad es de:")
print(edad)
print("Mi nombre es:")
print(nombre)
