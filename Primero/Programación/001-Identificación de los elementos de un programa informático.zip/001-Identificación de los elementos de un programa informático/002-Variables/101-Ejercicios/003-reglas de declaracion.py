edad = 47
miedad = 47
mi_edad = 47
# mi edad = 47
# mi-edad = 47
edad2 = 47
e2dad = 47
#2edad = 47


