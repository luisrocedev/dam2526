edad = 47
print("tengo",edad,"años")
edad = 48 # se puede variar el valor de una variable
print("tengo",edad,"años")

# variables en minúscula, constantes en mayúscula
PI = 3.1416
print("El valor de PI es:",PI)
PI = 4
print("El valor de PI es:",PI) # Funciona, pero no debe ocurrir

